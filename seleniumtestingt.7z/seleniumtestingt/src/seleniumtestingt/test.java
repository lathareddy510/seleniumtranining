package seleniumtestingt;

public @interface test {

}
