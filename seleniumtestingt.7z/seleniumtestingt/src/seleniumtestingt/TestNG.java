package seleniumtestingt;

public class TestNG {

	
		// TODO Auto-generated method stub
        
	   @test
	   public void Demo()
	   {
		   System.out.println("hello");
		   

	}

}
