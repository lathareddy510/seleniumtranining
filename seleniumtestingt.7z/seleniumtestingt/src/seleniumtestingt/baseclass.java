package seleniumtestingt;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class baseclass {
	
	public static void main(String args[]) {
		
		WebDriver driver = new ChromeDriver();
		System.setProperty("webdriver.chrome.driver", "C:\\selenium jars\\chromedriver.exe");
		driver.get("https://www.google.com");
		driver.getTitle();
		
		
	}

}
